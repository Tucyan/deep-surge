Deep Surge 事件节点预览资产 v1
- 共 12 张，对应 N01-N12。
- 来源：两张 21:9 六宫格预览图。
- 已移除红色分隔线并拆分为独立 PNG。
- 命名规则：NXX_english_name.png。
- 中文名称与文件名映射见 manifest.csv。
