Deep Surge 首版卡牌素材包 v1
- 共 24 张，对应 C01-C24。
- 文件格式：PNG / RGBA / 透明背景。
- 单张尺寸：724×543 px（4:3）。
- 命名规则：CXX_english_name.png。
- 中文名称与文件名映射见 manifest.csv。
